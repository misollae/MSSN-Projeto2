package physics;

public class Air extends Fluid {
	public Air() {
		super(1.29f);
	}
}
